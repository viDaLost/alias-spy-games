Moses: Nile Run — V7.3.7 full standalone web build

All runtime JavaScript, vendor files, textures and 3D models are included in this folder.

Run through a local HTTP server; opening index.html directly as file:// may block model/texture loading.

Example:
  python3 -m http.server 8080
Then open:
  http://localhost:8080/

Build assembled from branch: feature/moses-nile-runner-mvp
